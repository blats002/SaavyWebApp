module.exports = {
  assetsDir: 'custom-assets'
};