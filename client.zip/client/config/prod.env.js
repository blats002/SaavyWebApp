'use strict'
module.exports = {
  NODE_ENV: '"production"',
  SERVER_URL: '""'
}
